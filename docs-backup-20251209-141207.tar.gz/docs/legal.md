# Legal / Privacy Notice

- Client-side by default: files remain in your browser until you choose to upload media or translate. At that point they are sent directly to Google’s Gemini API using your API key. This app does not run its own server or store your data.
- You must provide your own Gemini API key; all billing/quotas are your responsibility.
- Do not upload material you lack rights to process. Follow applicable laws and platform terms.
- No warranty is provided; use at your own risk.
